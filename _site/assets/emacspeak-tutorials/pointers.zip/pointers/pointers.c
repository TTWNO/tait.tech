// This is a pointer demonstration.
#include <stdio.h>

int main() {
  int age = 21;
  printf("%d\n", age);
  printf("%p\n", &age);
  int* ptr = &age;
  printf("%p\n", ptr);
  *ptr += 1;
  printf("%d\n", age);
  printf("What is your age: ");
  scanf("%d", &age);
  printf("After user input: %d\n", age);
  return 0;
}
