// arrays

#include <stdio.h>
#define ARRLEN 7

int main() {
  int ages[ARRLEN];
  for (int i = 0; i < ARRLEN; i++) {
    printf("Age: ");
    scanf("%d", &ages[i]);
  }
  printf("Ages: ");
  for (int i = 0; i< ARRLEN ; i++) {
    printf("%d, ", ages[i]);
  }
  printf("\n");
  int sum = 0;
  for (int i = 0; i < ARRLEN; i++) {
    sum += ages[i];
  }
  printf("Sum: %d\n", sum);
  float arravg = sum / ARRLEN;
  printf("Average: %f\n", arravg);
  return 0;
}
