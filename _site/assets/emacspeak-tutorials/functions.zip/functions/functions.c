// how to modularize our program

#include <stdio.h>

int times2(int x) {
  return x * 2;
}
void ptrtimes2(int* x) {
  *x *= 2;
}
void prompt() {
  printf("Enter a number: ");
}
void timesx(int* x, int n) {
  *x *= n;
}
void the_math(int orig, int* newn, int multi) {
  *newn = times2(orig);
  ptrtimes2(newn);
  timesx(newn, multi);
}
int main() {
  int num, num2;
  prompt();
  scanf("%d", &num);
  the_math(num, &num2, 10);
  printf("Original is: %d\n", num);
  printf("Quadroupal is: %d\n", num2);
  return 0;
}
