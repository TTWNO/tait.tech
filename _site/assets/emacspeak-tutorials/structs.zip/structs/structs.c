// Structs and why we need them
#include <stdio.h>
#include <string.h>

struct Person {
  int age;
  char name[50];
};

void fill_vars(int* age, char* name) {
  printf("Enter the age: ");
  scanf("%d", age);
  printf("Enter the first name: ");
  scanf("%s", name);
}

void fill_vars_struct(struct Person* p) {
  printf("Enter the age: ");
  scanf("%d", &p->age);
  printf("Enter the name: ");
  scanf("%s", p->name);
}

int main() {
  int age;
  char name[50];
  fill_vars(&age, name);
  struct Person tait;
  fill_vars_struct(&tait);
  printf("Struct %s is %d years old\n", tait.name, tait.age);
  
  printf("%s is %d years old!\n", name, age);
  return 0;
}
