// how to do many things with few lines
#include <stdio.h>

int main() {
  for (int i = 0; i < 10; i++) {
    printf("5 times\n");
  }
  int j = 0;
  while (j < 3) {
    printf("3 times.\n");
    j++;
  }
	printf("Loopy loopy!\n");
	printf("Loopy loopy!\n");
	return 0;
}
