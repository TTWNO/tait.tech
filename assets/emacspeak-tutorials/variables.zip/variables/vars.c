// how to do variables and user input
#include <stdio.h>

int main() {
  int age;
  printf("Enter your age: ");
  scanf("%d", &age);
  printf("You are %d years old!\n", age);
  char name[50];
  printf("What is your name: ");
  scanf("%s", name);
  printf("Your name is %s!\n", name);
  return 0;
}
